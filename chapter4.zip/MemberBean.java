package chapter4;

import java.io.Serializable;

public class MemberBean implements Serializable{
	private static final long serialVersionUID = 6899684999423073826L;
	
	private int id;
	private String name;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
}
