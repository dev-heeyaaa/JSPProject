package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Operation
 */
@WebServlet("/operation")
public class Operation extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Operation() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		int first = Integer.parseInt(request.getParameter("first"));
//		int second = Integer.parseInt(request.getParameter("second"));
		
		String first = request.getParameter("first");
		String second = request.getParameter("second");
		
		int first_i = Integer.parseInt(first);
		int second_i = Integer.parseInt(second);
		
		int plus = first_i + second_i;
		int minus = first_i - second_i;
		int div = first_i / second_i;
		int mul = first_i * second_i;
		
		//request.setAttribute() �����ϱ�
		request.setAttribute("plus", plus);
		request.setAttribute("minus", minus);
		request.setAttribute("div", div);
		request.setAttribute("mul", mul);
		
		// RequestDispatcher�� ����ڰ� ��û�ϴ� �� �ƴ϶� �������� ��û�ϴ� �Ŵϱ� ����� url�� ��ȭ�� ����.
		//������ ����� /calcResult.jsp ���⼭ ���´�.
		RequestDispatcher dis = request.getRequestDispatcher("/calcResult.jsp");
		dis.forward(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);

		
	}

}
